document.addEventListener('DOMContentLoaded', () => {
    if ('scrollRestoration' in history) history.scrollRestoration = 'manual';
    let isAnimating = false;

    const updateHeaderHeight = () => {
        const sidebar = document.querySelector('.sidebar');
        if (sidebar && window.innerWidth <= 1100) {
            document.documentElement.style.setProperty('--header-height', `${sidebar.offsetHeight}px`);
        } else {
            document.documentElement.style.removeProperty('--header-height');
        }
    };
    updateHeaderHeight();
    window.addEventListener('resize', updateHeaderHeight);

    if (!history.state) history.replaceState({ url: location.href }, '', location.href);

    window.showToast = (msg, type = 'info') => {
        const c = document.getElementById('toast-container');
        if (!c) return;
        const t = document.createElement('div');
        t.className = 'toast';
        t.textContent = msg;
        c.appendChild(t);
        t.offsetHeight;
        t.classList.add('show');
        setTimeout(() => {
            t.classList.remove('show');
            setTimeout(() => t.remove(), 400);
        }, 3500);
    };

    const initScripts = () => {
        const searchForm = document.getElementById('search-form');
        if (searchForm) {
            searchForm.onsubmit = (e) => {
                e.preventDefault();
                const q = document.getElementById('search-input').value.toLowerCase().trim();
                const cards = document.querySelectorAll('.card');
                let found = 0;
                cards.forEach(card => {
                    const match = card.innerText.toLowerCase().includes(q);
                    card.style.display = match ? 'flex' : 'none';
                    if (match) found++;
                });
                if (!found) showToast('По вашему запросу ничего не найдено.', 'error');
                else if (q !== '') showToast(`Найдено мест: ${found}`, 'success');
            };
        }

        const addForm = document.querySelector('.add-form');
        if (addForm) {
            addForm.onsubmit = (e) => {
                e.preventDefault();
                showToast('Место успешно отправлено на модерацию!', 'success');
                addForm.reset();
            };
        }
    };

    initScripts();

    document.body.addEventListener('click', (e) => {
        const actionLink = e.target.closest('[data-action]');
        if (actionLink) {
            e.preventDefault();
            const act = actionLink.dataset.action;
            if (act === 'login') showToast('Страница входа в разработке', 'info');
            if (act === 'register') showToast('Страница регистрации в разработке', 'info');
            if (act === 'logout') {
                showToast('Вы вышли из системы', 'success');
                setTimeout(() => location.href = 'index.html', 1000);
            }
            return;
        }

        const link = e.target.closest('a');
        if (!link || link.target === '_blank') return;
        const href = link.getAttribute('href');
        
        if (href && href.startsWith('#')) {
            e.preventDefault();
            document.querySelector(href)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
            return;
        }

        if (!href || href.startsWith('http') || href.startsWith('mailto:')) return;
        if (location.pathname === new URL(href, location.origin).pathname) return;

        e.preventDefault();
        navigateTo(href);
    });

    window.addEventListener('popstate', (e) => {
        if (e.state && e.state.url) navigateTo(e.state.url, false);
        else location.reload();
    });

    async function navigateTo(url, pushState = true) {
        if (isAnimating) return;
        isAnimating = true;

        const content = document.querySelector('.content');
        const sidebar = document.querySelector('.sidebar');

        if (!content || !sidebar) return location.href = url;

        try {
            const html = await (await fetch(url)).text();
            const doc = new DOMParser().parseFromString(html, 'text/html');
            const newContent = doc.querySelector('.content').innerHTML;
            const newSidebar = doc.querySelector('.sidebar').innerHTML;
            const newTitle = doc.querySelector('title').innerText;

            sidebar.innerHTML = newSidebar;

            const overlay = document.createElement('div');
            overlay.className = 'page-overlay';
            overlay.innerHTML = newContent;
            
            document.body.appendChild(overlay);
            overlay.scrollTop = 0;

            document.documentElement.style.scrollBehavior = 'auto';
            window.scrollTo(0, 0);

            document.documentElement.style.overflow = 'hidden';
            document.body.style.overflow = 'hidden';

            content.classList.add('is-dimmed');

            overlay.offsetHeight; 
            overlay.classList.add('is-active');

            if (pushState) history.pushState({ url }, '', url);
            document.title = newTitle;

            overlay.addEventListener('transitionend', function onEnd(e) {
                if (e.propertyName !== 'transform') return;
                overlay.removeEventListener('transitionend', onEnd);

                const overlayScroll = overlay.scrollTop;

                content.style.transition = 'none';
                content.innerHTML = newContent;
                content.classList.remove('is-dimmed');
                
                void content.offsetHeight;
                content.style.transition = '';
                
                document.documentElement.style.overflow = '';
                document.body.style.overflow = '';

                window.scrollTo(0, overlayScroll);

                requestAnimationFrame(() => {
                    requestAnimationFrame(() => {
                        overlay.remove();
                        document.documentElement.style.scrollBehavior = '';
                        isAnimating = false;
                        initScripts();
                    });
                });
            });

        } catch (e) {
            location.href = url;
        }
    }
});