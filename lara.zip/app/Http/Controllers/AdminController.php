<?php

namespace App\Http\Controllers;

use App\Models\Order;
use Illuminate\Http\Request;

class AdminController extends Controller
{
    public function index() {
        abort_if(auth()->user()->role !== 'admin', 403);
        $orders = Order::with('user')->latest()->get();
        return view('admin.index', compact('orders'));
    }

    public function status(Request $request, Order $order) {
        abort_if(auth()->user()->role !== 'admin', 403);
        $request->validate(['status' => 'required|in:new,processing,completed']);
        $order->update(['status' => $request->status]);
        return back();
    }
}