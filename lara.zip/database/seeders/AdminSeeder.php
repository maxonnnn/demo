<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class AdminSeeder extends Seeder
{
    public function run(): void
    {
        User::create([
            'login'     => 'Admin33',
            'full_name' => 'Администратор',
            'email'     => 'admin@example.com',
            'password'  => Hash::make('AdminVeb33'),
            'role'      => 'admin',
        ]);
    }
}