@extends('layouts.app')

@section('content')
<div class="container">
    <h3 class="mb-3">Все заказы</h3>

    <table class="table table-bordered align-middle">
        <thead class="table-light">
            <tr>
                <th>Логин</th>
                <th>Книга</th>
                <th>Кол-во</th>
                <th>Дата</th>
                <th>Статус</th>
            </tr>
        </thead>
        <tbody>
            @foreach($orders as $order)
            <tr>
                <td>{{ $order->user->login }}</td>
                <td>{{ $order->book_name }}</td>
                <td>{{ $order->quantity }}</td>
                <td>{{ $order->delivery_date }}</td>
                <td>
                    <form method="POST" action="{{ route('admin.status', $order) }}">
                        @csrf
                        @method('PUT')
                        <select name="status" class="form-select form-select-sm" onchange="this.form.submit()">
                            <option value="new"        @selected($order->status === 'new')>Новый</option>
                            <option value="processing" @selected($order->status === 'processing')>В обработке</option>
                            <option value="completed"  @selected($order->status === 'completed')>Завершён</option>
                        </select>
                    </form>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endsection