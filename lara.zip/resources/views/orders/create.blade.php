@extends('layouts.app')

@section('content')
<div class="container">
    <h3 class="mb-3">Новый заказ</h3>

    <form method="POST" action="{{ route('orders.store') }}">
        @csrf

        <div class="row g-3 mb-3">
            @foreach([
                ['title' => 'Мастер и Маргарита',       'img' => '1.webp'],
                ['title' => 'Война и мир',              'img' => '2.jpg'],
                ['title' => 'Преступление и наказание', 'img' => '3.jpg'],
                ['title' => 'Идиот',                    'img' => '4.jpg'],
            ] as $i => $book)
            <div class="col-6 col-md-3">
                <input type="radio" name="book_name" id="b{{ $i }}" value="{{ $book['title'] }}" class="d-none book-radio" required>
                <label for="b{{ $i }}" class="card book-card h-100">
                    <img src="{{ asset('images/' . $book['img']) }}"class="card-img-top"alt="{{ $book['title'] }}"style="aspect-ratio: 2 / 3; object-fit: cover; width: 100%;">
                    <div class="card-body text-center p-2">
                        <div class="fw-bold small">{{ $book['title'] }}</div>
                    </div>
                </label>
            </div>
            @endforeach
        </div>

        <div class="row g-3 mb-3">
            <div class="col-md-6">
                <label class="form-label">Количество</label>
                <input type="number" name="quantity" value="1" min="1" class="form-control" required>
            </div>
            <div class="col-md-6">
                <label class="form-label">Дата доставки</label>
                <input type="date" name="delivery_date" class="form-control" required>
            </div>
        </div>

        <button class="btn btn-primary">Отправить</button>
    </form>
</div>

<style>
    .book-card { cursor: pointer; border: 2px solid #dee2e6; }
    .book-card:hover { border-color: #0d6efd; }
    .book-radio:checked + .book-card { border-color: #0d6efd; background: #e7f1ff; }
</style>
@endsection