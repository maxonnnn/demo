@extends('layouts.app')

@section('content')
<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="mb-0">Мои заказы</h2>
        <a href="{{ route('orders.create') }}" class="btn btn-primary">+ Новый заказ</a>
    </div>

    @if($orders->isEmpty())
        <div class="text-center text-muted py-5">
            <p class="mb-3">У вас пока нет заказов.</p>
            <a href="{{ route('orders.create') }}" class="btn btn-primary">Создать первый заказ</a>
        </div>
    @else
        <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
            @foreach($orders as $order)
            <div class="col">
                <div class="card h-100 shadow-sm">
                    <div class="card-body">
                        <h5 class="card-title">{{ $order->book_name }}</h5>
                        <p class="card-text text-muted mb-2">
                            Количество: <strong>{{ $order->quantity }}</strong>
                        </p>
                        <p class="card-text text-muted mb-2">
                            Доставка: <strong>{{ $order->delivery_date }}</strong>
                        </p>
                        <p class="card-text mb-0">
                            @if($order->status === 'new')
                                <span class="badge bg-primary">Новый</span>
                            @elseif($order->status === 'processing')
                                <span class="badge bg-warning text-dark">В обработке</span>
                            @elseif($order->status === 'completed')
                                <span class="badge bg-success">Завершён</span>
                            @else
                                <span class="badge bg-secondary">{{ $order->status }}</span>
                            @endif
                        </p>
                    </div>
                    <div class="card-footer bg-white border-0 text-muted small">
                        Создан: {{ $order->created_at->format('d.m.Y H:i') }}
                    </div>
                </div>
            </div>
            @endforeach
        </div>
    @endif
</div>
@endsection