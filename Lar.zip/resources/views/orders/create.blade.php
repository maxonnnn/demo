
@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('Dashboard') }}</div>

                <div class="card-body">
                    <form method="POST" action="{{ route('orders.store') }}">
                        @csrf
                        <select name="book_name" class="form-control mb-3" required>
                            <option>Мастер и Маргарита</option>
                            <option>Война и мир</option>
                            <option>Преступление и наказание</option>
                            <option>Идиот</option>
                        </select>
                        <input type="number" name="quantity" value="1" class="form-control mb-3" required>
                        <input type="date" name="delivery_date" class="form-control mb-3" required>
                        <button class="btn btn-primary">Отправить</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
