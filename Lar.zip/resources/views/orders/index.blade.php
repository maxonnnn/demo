@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('Dashboard') }}</div>

                <div class="card-body">
                    @if($orders->isEmpty())
                        <p><a href="{{ route('orders.create') }}">Создать заказ</a></p>
                    @else
                    <table class="table table-bordered">
                        <tr><th>Книга</th><th>Кол-во</th><th>Дата</th><th>Статус</th></tr>
                        @foreach($orders as $order)
                        <tr>
                            <td>{{ $order->book_name }}</td>
                            <td>{{ $order->quantity }}</td>
                            <td>{{ $order->delivery_date }}</td>
                            <td>{{ $order->status == 'new' ? 'Новый' : $order->status }}</td>
                        </tr>
                        @endforeach
                    </table>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
