<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\OrderController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return auth()->check()
        ? redirect()->route('orders.index')
        : redirect()->route('login');
});

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

Route::middleware('auth')->group(function () {
    Route::get('/orders',         [OrderController::class, 'index'])->name('orders.index');
    Route::view('/orders/create', 'orders.create')->name('orders.create');
    Route::post('/orders',        [OrderController::class, 'store'])->name('orders.store');
});

use App\Http\Controllers\AdminController;

Route::middleware('auth')->group(function () {
    Route::get('/admin',              [AdminController::class, 'index'])->name('admin.index');
    Route::put('/admin/orders/{order}', [AdminController::class, 'status'])->name('admin.status');
});

Route::put('/orders/{order}/review', [OrderController::class, 'review'])->name('orders.review');