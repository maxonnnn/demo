<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class AdminSeeder extends Seeder
{
    public function run(): void
    {
        User::create([
            'login'     => 'Conf2027',
            'full_name' => 'Администратор',
            'phone'     => '8(999)000-00-00',
            'email'     => 'admin@conf.rf',
            'password'  => Hash::make('Demo77'),
            'role'      => 'admin',
        ]);
    }
}