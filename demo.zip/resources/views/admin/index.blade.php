@extends('layouts.app')

@section('content')
<div class="container">
    <h3 class="mb-3">Все заявки</h3>

    <table class="table table-bordered align-middle">
        <thead class="table-light">
            <tr>
                <th>Логин</th>
                <th>ФИО</th>
                <th>Телефон</th>
                <th>Помещение</th>
                <th>Дата</th>
                <th>Оплата</th>
                <th>Статус</th>
            </tr>
        </thead>
        <tbody>
            @foreach($orders as $order)
            <tr>
                <td>{{ $order->user->login }}</td>
                <td>{{ $order->user->full_name }}</td>
                <td>{{ $order->user->phone }}</td>
                <td>{{ $order->room_name }}</td>
                <td>{{ $order->start_date }}</td>
                <td>{{ $order->payment_method === 'sbp' ? 'СБП' : 'Очное' }}</td>
                <td>
                    <form method="POST" action="{{ route('admin.status', $order) }}">
                        @csrf @method('PUT')
                        <select name="status" class="form-select form-select-sm" onchange="this.form.submit()">
                            <option value="new"       @selected($order->status === 'new')>Новая</option>
                            <option value="assigned"  @selected($order->status === 'assigned')>Мероприятие назначено</option>
                            <option value="completed" @selected($order->status === 'completed')>Завершено</option>
                        </select>
                    </form>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endsection