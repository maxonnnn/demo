@extends('layouts.app')

@section('content')
<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3 class="mb-0">Мои заявки</h3>
        <a href="{{ route('orders.create') }}" class="btn btn-primary">Новая заявка</a>
    </div>

    @if($orders->isEmpty())
        <div class="alert alert-info text-center py-4">
            <p class="mb-3">У вас пока нет заявок.</p>
            <a href="{{ route('orders.create') }}" class="btn btn-primary btn-sm">Создать первую</a>
        </div>
    @else
        <div class="row g-4">
            @foreach($orders as $order)
            <div class="col-md-6 col-lg-4">
                <div class="card h-100 shadow-sm border-0">
                    <!-- Заголовок карточки -->
                    <div class="card-header bg-white d-flex justify-content-between align-items-center py-3 border-bottom-0">
                        <h5 class="mb-0 fw-bold">{{ $order->room_name }}</h5>
                        @if($order->status === 'new')
                            <span class="badge bg-primary rounded-pill">Новая</span>
                        @elseif($order->status === 'assigned')
                            <span class="badge bg-warning text-dark rounded-pill">Назначено</span>
                        @elseif($order->status === 'completed')
                            <span class="badge bg-success rounded-pill">Завершено</span>
                        @endif
                    </div>

                    <div class="card-body py-2">
                        <ul class="list-unstyled mb-0 text-muted small">
                            <li class="mb-2 d-flex justify-content-between">
                                <span>Дата:</span>
                                <span class="text-dark fw-semibold">{{ \Carbon\Carbon::parse($order->start_date)->format('d.m.Y') }}</span>
                            </li>
                            <li class="d-flex justify-content-between">
                                <span>Оплата:</span>
                                <span class="text-dark fw-semibold">{{ $order->payment_method === 'sbp' ? 'СБП' : 'Очное' }}</span>
                            </li>
                        </ul>
                    </div>

                    <div class="card-footer bg-light border-top-0 mt-auto">
                        @if($order->review)
                            <div class="small">
                                <span class="text-muted fst-italic">Ваш отзыв:</span><br>
                                «{{ $order->review }}»
                            </div>
                        @elseif($order->status === 'completed')
                            <form method="POST" action="{{ route('orders.review', $order) }}" class="review-form">
                                @csrf @method('PUT')
                               <div class="star-rating">
                                    @for($i = 5; $i >= 1; $i--)
                                        <input type="radio" name="rating" id="star-{{ $order->id }}-{{ $i }}" value="{{ $i }}" class="d-none">
                                        <label for="star-{{ $order->id }}-{{ $i }}" class="star">★</label>
                                    @endfor
                                </div>
                                <textarea name="review" class="form-control form-control-sm mb-2" rows="2" placeholder="Поделитесь впечатлениями..."></textarea>
                                <button class="btn btn-sm btn-outline-success w-100">Отправить</button>
                            </form>
                        @else
                            <div class="small text-muted text-center py-2">
                                Отзыв можно будет оставить после завершения
                            </div>
                        @endif
                    </div>
                </div>
            </div>
            @endforeach
        </div>
    @endif
</div>

<style>
    .star-rating { display: flex; flex-direction: row-reverse; justify-content: flex-end; }
    .star-rating .star { cursor: pointer; font-size: 1.5rem; color: #ccc; user-select: none; transition: color .15s; }
    .star-rating input:checked ~ .star,
    .star-rating .star:hover,
    .star-rating .star:hover ~ .star { color: #ffc107; }

    .star {
    user-select: none;
    -webkit-user-select: none;
    cursor: pointer;
    display: inline-block;
}
</style>
@endsection