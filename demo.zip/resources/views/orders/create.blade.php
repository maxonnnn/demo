@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card shadow-sm">
                <div class="card-header bg-white">
                    <h4 class="mb-0">Новая заявка</h4>
                </div>

                <div class="card-body">
                    <form method="POST" action="{{ route('orders.store') }}">
                        @csrf

                        <label class="form-label fw-bold mb-3">Выберите помещение</label>
                        
                        <div class="row g-3 mb-4">
                            @foreach([
                                ['name' => 'Аудитория', 'img' => '1.jpg'],
                                ['name' => 'Коворкинг', 'img' => '2.jpg'],
                                ['name' => 'Кинозал',   'img' => '3.jpg'],
                            ] as $i => $room)
                            <div class="col-md-4">
                                <input type="radio" name="room_name" id="room{{ $i }}" value="{{ $room['name'] }}" class="d-none room-radio" required>
                                <label for="room{{ $i }}" class="card room-card h-100 border-2 text-decoration-none text-dark">
                                    <img src="{{ asset('images/' . $room['img']) }}" class="card-img-top" alt="{{ $room['name'] }}" style="aspect-ratio: 4/3; object-fit: cover;">
                                    <div class="card-body text-center py-3">
                                        <h5 class="mb-0 fw-bold">{{ $room['name'] }}</h5>
                                    </div>
                                    <div class="position-absolute top-0 end-0 m-2 badge bg-primary rounded-circle p-2 check-mark d-none">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
                                            <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                                        </svg>
                                    </div>
                                </label>
                            </div>
                            @endforeach
                        </div>

                        @error('room_name')
                            <div class="text-danger small mb-3">{{ $message }}</div>
                        @enderror

                        <div class="row g-3 mb-4">
                            <div class="col-md-6">
                                <label class="form-label">Дата начала конференции</label>
                                <input type="date" name="start_date" class="form-control" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Способ оплаты</label>
                                <select name="payment_method" class="form-select" required>
                                    <option value="onsite">При очном посещении</option>
                                    <option value="sbp">Переводом по СБП</option>
                                </select>
                            </div>
                        </div>

                        <div class="d-flex gap-2 mt-4">
                            <button class="btn btn-primary px-4">Отправить</button>
                            <a href="{{ route('orders.index') }}" class="btn btn-outline-secondary">Отмена</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .room-card {
        cursor: pointer;
        transition: all .15s ease;
        border: 2px solid #dee2e6;
        position: relative;
        overflow: hidden;
    }
    .room-card:hover {
        border-color: #0d6efd;
        transform: translateY(-3px);
        box-shadow: 0 .5rem 1rem rgba(13,110,253,.15);
    }
    .room-radio:checked + .room-card {
        border-color: #0d6efd;
        background-color: #f0f6ff;
        box-shadow: 0 0 0 .25rem rgba(13,110,253,.25);
    }
    .room-radio:checked + .room-card .check-mark {
        display: block !important;
    }
</style>
@include('partials.reviews')
@endsection