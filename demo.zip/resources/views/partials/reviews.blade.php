@php
    $reviews = \App\Models\Order::whereNotNull('review')->latest()->take(5)->get();
@endphp

@if($reviews->isNotEmpty())
    <div class="mt-5">
        <h5 class="mb-3 text-muted text-center">Отзывы о мероприятиях</h5>
        <div class="row g-3 justify-content-center">
            @foreach($reviews as $review)
            <div class="col-md-4">
                <div class="card bg-light border-0 h-100">
                    <div class="card-body">
                        <div class="text-warning mb-2">
                            @if($review->rating)
                                <span style="font-size: 1.1rem;">{{ str_repeat('★', $review->rating) }}</span>
                                <span class="text-muted small ms-1">({{ $review->rating }} из 5)</span>
                            @else
                                <span class="text-muted small fst-italic">Без оценки</span>
                            @endif
                        </div>
                        <p class="mb-2 fst-italic">«{{ $review->review }}»</p>
                        <small class="text-muted">
                            — {{ $review->user->full_name ?? 'Пользователь' }}, 
                            {{ $review->room_name }}
                        </small>
                    </div>
                </div>
            </div>
            @endforeach
        </div>
    </div>
@endif