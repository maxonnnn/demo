<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use App\Models\User;
use Illuminate\Foundation\Auth\RegistersUsers;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class RegisterController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Register Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users as well as their
    | validation and creation. By default this controller uses a trait to
    | provide this functionality without requiring any additional code.
    |
    */

    use RegistersUsers;

    /**
     * Where to redirect users after registration.
     *
     * @var string
     */
    protected $redirectTo = RouteServiceProvider::HOME;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest');
    }

    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator(array $data)
    {
        return Validator::make($data, [
            'login'     => ['required', 'regex:/^[a-zA-Z0-9]{6,}$/', 'unique:users'],
            'full_name' => 'required|regex:/^[А-Яа-яЁё\s]+$/u',
            'phone' => 'required|regex:/^\(\d{3}\) \d{3}-\d{2}-\d{2}$/',
            'email'     => 'required|email|unique:users',
            'password'  => 'required|min:8',
        ], [
            'login.regex'     => 'Логин: только латиница и цифры, минимум 6 символов.',
            'full_name.regex' => 'ФИО: только кириллица и пробелы.',
            'phone.regex'     => 'Телефон в формате 8(XXX)XXX-XX-XX.',
            'password.min'    => 'Пароль должен быть минимум 8 символов.',
        ]);
    }

    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return \App\Models\User
     */
    protected function create(array $data)
    {
        return User::create([
            'login'     => $data['login'],
            'full_name' => $data['full_name'],
            'phone'     => $data['phone'],
            'email'     => $data['email'],
            'password'  => Hash::make($data['password']),
            'role'      => 'user',
        ]);
    }
}
