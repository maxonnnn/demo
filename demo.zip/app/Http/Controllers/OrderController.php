<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Order;

class OrderController extends Controller
{
    public function index() {
        return view('orders.index', [
            'orders' => Order::where('user_id', auth()->id())->get(),
        ]);
    }

    public function store(Request $request) {
        $request->validate([
            'room_name'      => 'required|string',
            'start_date'     => 'required|date',
            'payment_method' => 'required|in:onsite,sbp',
        ]);
        Order::create([
            'user_id'        => auth()->id(),
            'room_name'      => $request->room_name,
            'start_date'     => $request->start_date,
            'payment_method' => $request->payment_method,
        ]);
        return redirect('/orders');
    }

    public function review(Request $request, Order $order) {
        abort_if($order->user_id !== auth()->id(), 403);
        
        $request->validate([
            'review' => 'nullable|string|max:1000',
            'rating' => 'nullable|integer|min:1|max:5',
        ]);
        
        if ($request->filled('review') || $request->filled('rating')) {
            $order->update([
                'review' => $request->review,
                'rating' => $request->rating,
            ]);
        }
        return back();
    }
}
