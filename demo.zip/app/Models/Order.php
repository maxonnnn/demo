<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    protected $fillable = ['user_id', 'room_name', 'start_date', 'payment_method', 'status', 'review', 'rating'];
    public function user() { return $this->belongsTo(User::class); }
}
